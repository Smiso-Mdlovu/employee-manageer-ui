export interface Employee {
  id: number;
  name: String;
  email: String;
  phone: String;
  jobTitle: String;
  imageUrl: string;
  employeeCode: String;
}
